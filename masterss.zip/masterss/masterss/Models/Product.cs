﻿using System.ComponentModel.DataAnnotations;

namespace masterss.Models
{
	public class Product
	{
		public int Id { get; set; }

		[Display(Name = "Product Name")]
		public string ProductName { get; set; }

		[Display(Name = "Product Code")]
		public string ProductCode { get; set; }

		public string Discription { get; set; }

		public virtual List<PurchaseProduct> PurchaseProducts { get; set; } = new List<PurchaseProduct>();



	}
}

